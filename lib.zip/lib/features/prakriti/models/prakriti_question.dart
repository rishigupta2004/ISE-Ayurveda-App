class PrakritiQuestion {
  final String question;
  final String vataOption;
  final String pittaOption;
  final String kaphaOption;

  PrakritiQuestion({
    required this.question,
    required this.vataOption,
    required this.pittaOption,
    required this.kaphaOption,
  });
}